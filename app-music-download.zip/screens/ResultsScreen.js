import React from 'react';
import { View, Text, TouchableOpacity, ImageBackground } from 'react-native';
import { styles } from '../styles/common';

// ResultsScreen independiente (sin navegación ni route)
export default function ResultsScreen(props) {
  // Puedes pasar searchTerm y premiumMode como props, o dejar valores por defecto:
  const searchTerm = props?.searchTerm ?? 'Bohemian Rhapsody';
  const premiumMode = props?.premiumMode ?? false;

  // Datos de ejemplo (simulando resultados de búsqueda)
  const results = [
    { id: 1, title: 'Bohemian Rhapsody', artist: 'Queen', premium: false },
    { id: 2, title: 'Shape of You', artist: 'Ed Sheeran', premium: false },
    { id: 3, title: 'Blinding Lights', artist: 'The Weeknd', premium: true },
    { id: 4, title: 'Dance Monkey', artist: 'Tones and I', premium: false },
    { id: 5, title: 'Exclusivo: Nuevo Álbum', artist: 'Artista Premium', premium: true },
  ];

  // Filtrar resultados según modo premium
  const filteredResults = premiumMode 
    ? results 
    : results.filter(item => !item.premium);

  return (
    <ImageBackground 
      source={{uri: 'https://i.pinimg.com/736x/8f/0a/8e/8f0a8e2d8c3c3c3c3c3c3c3c3c3c3c3c.jpg'}} 
      style={styles.backgroundImage}
      blurRadius={2}
    >
      <View style={styles.container}>
        <View style={styles.header}>
          {/* Botón de regreso eliminado para independencia */}
          <Text style={styles.title}>
            Resultados para: {searchTerm}
          </Text>
          <Text style={styles.subtitle}>
            {premiumMode ? 'Modo Premium Activado' : 'Modo Gratuito'}
          </Text>
        </View>
        
        <View style={styles.resultsContainer}>
          <View style={styles.resultsHeader}>
            <Text style={styles.resultsTitle}>
              {filteredResults.length} resultados encontrados
            </Text>
            {!premiumMode && (
              <Text style={styles.premiumHint}>
                Activa el modo premium para ver todos los resultados
              </Text>
            )}
          </View>
          
          {filteredResults.map((item) => (
            <View 
              key={item.id} 
              style={[
                styles.resultItem,
                item.premium && styles.premiumItem
              ]}
            >
              <View style={styles.songInfo}>
                <Text style={styles.songTitle}>{item.title}</Text>
                <Text style={styles.songArtist}>{item.artist}</Text>
              </View>
              {item.premium && (
                <Text style={styles.premiumBadge}>PREMIUM</Text>
              )}
            </View>
          ))}
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            © 2025 VidSnap | Todos los derechos reservados
          </Text>
        </View>
      </View>
    </ImageBackground>
  );
}
