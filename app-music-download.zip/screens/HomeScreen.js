import React, { useState } from 'react';
import {
  Text,
  Image,
  Alert,
  Switch,
  TextInput,
  View,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity
} from 'react-native';


import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Permissions from 'expo-permissions';


import { styles } from '../styles/common'
import { useDounloader } from '../service/useDownloader';


// HomeScreen component (sin navegación)
export default function HomeScreen() {
  const [inputText, setInputText] = useState('');
  const [switchValue, setSwitchValue] = useState(false);




  // Mostrar alerta si el campo está vacío al presionar el botón
  const handleSearch = async () => {
    if (!inputText.trim()) {
      Alert.alert('Campo vacío', 'Por favor, escribe algo en el campo de búsqueda.');
      return;
    }


    const formato = switchValue ? 'mp4' : 'mp3';
    const filename = 'VidSnap_${Date.now()}.${formato}'
    const fileUri = FileSystem.documentDirectory + filename;


    try {
      const blob=await useDounloader(inputText,formato);
      const reader=new FileReader();

      reader.onload=async()=>{
        const buffer=reader.result.split(',')[1];
        await FileSystem.EncodingType.Base64;
      }

    } catch (error) {

    }



    // Aquí puedes agregar lógica para manejar la descarga o búsqueda directamente
    Alert.alert('Descarga', `Descargando: ${inputText} en formato ${switchValue ? 'mp4' : 'mp3'}`);
  };



  // Función para cambiar el switch
  const toggleSwitch = (value) => {
    setSwitchValue(value);
    console.warn(`El switch cambiará a: ${value}`);
  };

  return (
    <ImageBackground
      source={{ uri: 'https://i.pinimg.com/736x/8f/0a/8e/8f0a8e2d8c3c3c3c3c3c3c3c3c3c3c3c.jpg' }}
      style={styles.backgroundImage}
      blurRadius={2}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <View style={styles.container}>
          <View style={styles.header}>

            <View style={styles.logoContainer}>
              <Image source={require('../assets/image.webp')}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>

            <Text style={styles.subtitle}>
              Tu aplicación de descarga de música
            </Text>
          </View>

          <View style={styles.content}>
            <TextInput
              style={styles.input}
              placeholder="Youtube Link de Desgarga ..."
              placeholderTextColor="#a0a0a0"
              value={inputText}
              onChangeText={text => setInputText(text)}
              selectionColor="#ff00cc"
            />

            <View style={styles.switchContainer}>
              <View style={styles.switchLabelContainer}>
                <Text style={styles.switchLabel}>
                  Modo de Descarga
                </Text>
                <Text style={styles.switchStatus}>
                  {switchValue ? 'mp4' : 'mp3'}
                </Text>
              </View>
              <Switch
                trackColor={{ false: "#444", true: "rgba(204, 0, 153, 0.5)" }}
                thumbColor={switchValue ? "#ff00cc" : "#f4f3f4"}
                ios_backgroundColor="#3e3e3e"
                onValueChange={toggleSwitch}
                value={switchValue}
              />
            </View>

            <TouchableOpacity
              style={styles.customButton}
              onPress={handleSearch}
            >
              <Text style={styles.buttonText}>Iniciar Descarga</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              © 2025 VidSnap | Todos los derechos reservados
            </Text>
            <Text style={styles.footerLink}>
              Guarda para obtener un enlace compartible
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}
