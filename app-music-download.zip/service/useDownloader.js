export const useDounloader = async(url,formato='mp3')=>{
  
     const BACKEND_URL='';

    const response=await fetch(BACKEND_URL,{
       method: 'POST',
       headers: {'Content-Type':'application/json'},
       body:JSON.stringigy({url,formato}),

    });

    if(!response.ok){
        throw new Error('Algo salió mal')
    }

    return response.blob()


}